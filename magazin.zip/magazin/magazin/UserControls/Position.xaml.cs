﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using magazin.Models;
namespace magazin.UserControls
{
    /// <summary>
    /// Логика взаимодействия для Position.xaml
    /// </summary>
    public partial class Position : UserControl
    {
        public Position(Models.Basket basket, int num)
        {
            InitializeComponent();
            Name.Text = basket.CatalogTovarNameModel;
            Quantity.Text = basket.QuantityTovar.ToString();
            if (basket.QuantityTovar >= 3)
                Classes.Basket.discount = 10;
            Cost.Text = basket.Cost.ToString();
            Number.Text = (num + 1).ToString();
        }
    }
}
