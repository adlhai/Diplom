﻿using magazin.Models;
using magazin.Pages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.UserControls
{
    /// <summary>
    /// Логика взаимодействия для Catalog.xaml
    /// </summary>
    public partial class Catalog : UserControl
    {
        CatalogTovar tovar;
        public Catalog(Models.CatalogTovar tovar)
        {
            InitializeComponent();
            this.tovar = tovar;
            Name.Text += tovar.NameModel;
            Description.Text += tovar.DescriptionTovar;
            Purpose.Text += tovar.PurposeName;
            this.Type.Text += tovar.TypeName;
            Cost.Text += tovar.Cost + " руб.";
            if (tovar.Photo.Length != 0)
            {
                BitmapImage bi = new BitmapImage();
                MemoryStream ms = new MemoryStream(tovar.Photo);
                bi.BeginInit();
                bi.StreamSource = ms;
                bi.EndInit();
                Img.Source = bi;
            }
            List<Models.SizeTovarCatalog> sizes = App.context.SizeTovarCatalog.ToList().Where(s => s.IdCatalogTovar == tovar.IdCatalogTovar).ToList();
            foreach (var size in sizes)
            {
                ComboBoxItem cbi = new ComboBoxItem();
                TextBlock tb = new TextBlock();
                Models.Size size1 = App.context.Size.ToList().Find(s => s.IdSize == size.IdSize);
                tb.Text = size1.SizeTovar + " размер (" + size.QuantityTovar + " пар)";
                cbi.Content = tb;
                Sizes.Items.Add(cbi);
            }
        }

        private void change_Click(object sender, RoutedEventArgs e)
        {
            Models.User user1 = App.context.User.ToList().Find(u => u.IdUser == Classes.Profile.UserId);
            if (user1.IdRole == 2)
            {
                Classes.Manager.MainFrame.Navigate(new TovarAdd((sender as Button).DataContext as CatalogTovar));
            }
            else
            {
                MessageBox.Show("У вас нет доступа", "Ошибка");
            }
        }

        private void del_Click(object sender, RoutedEventArgs e)
        {
            User user1 = App.context.User.ToList().Find(u => u.IdUser == Classes.Profile.UserId);
            if (user1.IdRole == 2)
            {
                if (MessageBox.Show($"Вы точно хотите удалить элемет", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        App.context.CatalogTovar.Remove(tovar);
                        App.context.SaveChanges();
                        MessageBox.Show("Информация удалена");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.Message.ToString());
                    }
                }
            }
            else
            {
                MessageBox.Show("У вас нет доступа", "Ошибка");
            }

        }
    }
}
