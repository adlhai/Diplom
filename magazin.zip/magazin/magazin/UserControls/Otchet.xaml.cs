﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.UserControls
{
    /// <summary>
    /// Логика взаимодействия для Otchet.xaml
    /// </summary>
    public partial class Otchet : UserControl
    {
        public Otchet(Models.Basket basket)
        {
            InitializeComponent();
            Models.Orders order = App.context.Orders.ToList().Find(o => o.IdOrder == basket.IdOrder);
            Method.Text = order.MetodOplata;
            Date.Text = order.DateOrder.ToString("dd.MM.yyyy");
            Title.Text = basket.CatalogTovarNameModel;
            Quantity.Text = basket.QuantityTovar.ToString();
            Article.Text = basket.Article;
            if (basket.QuantityTovar >= 3)
            {
                Cost.Text = ((Convert.ToInt32(basket.Cost) * basket.QuantityTovar) - (Convert.ToInt32(basket.Cost) * basket.QuantityTovar) / 10).ToString();
            }
            else
                Cost.Text = (Convert.ToInt32(basket.Cost) * basket.QuantityTovar).ToString();
        }
    }
}
