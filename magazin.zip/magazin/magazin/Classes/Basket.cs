﻿using System;
using System.Collections.Generic;
using System.Text;
using magazin.Models;
namespace magazin.Classes
{
    internal class Basket
    {
        public static List<CatalogTovar> tovars = new List<CatalogTovar>();
        public static List<int> Sizes = new List<int>();
        public static int discount = 0;
    }
}
