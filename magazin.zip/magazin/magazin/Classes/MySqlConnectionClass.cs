﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace magazin.Classes
{
    internal class MySqlConnectionClass
    {
        public static MySqlConnection connection = new MySqlConnection(@"Server = localhost;Database= magazin;port= 3306;User Id= root;password=adelina2601");

        public void openConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Open();
            }
        }

        public void closeConnection()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Close();

            }
        }

        public MySqlConnection GetMySqlConnection()
        {
            return connection;
        }

    }
}
