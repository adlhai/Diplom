﻿using System;
using System.Collections.Generic;
using System.Text;

namespace magazin.Classes
{
    internal class Update
    {
        public static Pages.Chek chek;
    }
}
