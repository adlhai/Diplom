﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;

namespace magazin.Classes
{
    internal class Manager
    {
        public static Frame MainFrame { get; set; }
        public static int kolvoframe;
    }
}
