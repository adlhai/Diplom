﻿using System;
using System.Collections.Generic;
using System.Text;

namespace magazin.Classes
{
    internal class ConstantData
    {
        public static Windows.Authorization auth;
        public static string Atricle;
        public static MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection
            ("server=localhost;user=root;pwd=adelina2601;database=magazin");
    }
}
