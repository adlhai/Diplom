﻿using System;
using System.Collections.Generic;
using System.Text;

namespace magazin.Classes
{
    internal class Profile
    {
        public static int UserId;
        public static int Role;
        public static string FIOUSER;
    }
}
