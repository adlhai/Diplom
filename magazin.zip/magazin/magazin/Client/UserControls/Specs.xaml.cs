﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Client.UserControls
{
    /// <summary>
    /// Логика взаимодействия для Specs.xaml
    /// </summary>
    public partial class Specs : UserControl
    {
        public Specs(Models.Basket basket)
        {
            InitializeComponent();
            Models.CatalogTovar tovar = App.context.CatalogTovar.ToList().Find(t => t.IdCatalogTovar == basket.IdCatalog);
            Title.Text = tovar.NameModel;
            Quantity.Text = basket.QuantityTovar.ToString();
            Cost.Text = (basket.QuantityTovar * tovar.Cost).ToString();
        }
        Models.CatalogTovar tovar;
    }
}
