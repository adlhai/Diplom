﻿using magazin.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Client.UserControls
{
    /// <summary>
    /// Логика взаимодействия для Product.xaml
    /// </summary>
    public partial class Product : UserControl
    {
        public Product(CatalogTovar tovar)
        {
            InitializeComponent();
            Name.Text = tovar.NameModel;
            this.tovar = tovar;
            BitmapImage img = new BitmapImage();
            MemoryStream ms = new MemoryStream(tovar.Photo);
            img.BeginInit();
            img.StreamSource = ms;
            img.EndInit();
            Img.Source = img;
            Cost.Text = tovar.Cost + " р.";
            List<SizeTovarCatalog> sizes = App.context.SizeTovarCatalog.ToList().Where(s => s.IdCatalogTovar == tovar.IdCatalogTovar).ToList();
            foreach (var item in sizes)
            {
                Models.Size si = App.context.Size.ToList().Find(s => s.IdSize == item.IdSize);
                Size.Items.Add(si.SizeTovar);
            }
        }
        CatalogTovar tovar;

        private void Back_MouseEnter(object sender, MouseEventArgs e)
        {
            Back.Background = MouseEnter.Background;
        }

        private void Back_MouseLeave(object sender, MouseEventArgs e)
        {
            Back.Background = MouseLeave.Background;
        }

        private void Back_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (Size.Text.Length != 0)
            {
                Models.Size s = App.context.Size.ToList().Find(si => si.SizeTovar == Convert.ToInt32(Size.Text));
                SizeTovarCatalog sizes = App.context.SizeTovarCatalog.ToList().Find(si => si.IdSize == s.IdSize);
                List<int> count = Classes.Basket.Sizes.Where(cou => cou == s.IdSize).ToList();
                if (sizes != null)
                {
                    if ((count.Count + 1) > sizes.QuantityTovar)
                    {
                        MessageBox.Show("Такого размера в таком количестве нет!");
                    }
                    else
                    {
                        Classes.Basket.tovars.Add(tovar);
                        Classes.Basket.Sizes.Add(s.IdSize);

                        Classes.Navigation.cart.LoadData();
                        if (count.Count >= 3)
                        {
                            Classes.Basket.discount = 10;
                        }
                    }

                }
            }
            else
                MessageBox.Show("Вы должны выбрать размер!");
        }
    }
}
