﻿using magazin.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Client.UserControls
{
    /// <summary>
    /// Логика взаимодействия для Basket.xaml
    /// </summary>
    public partial class Basket : UserControl
    {
        public Basket(CatalogTovar tovar, int Size)
        {
            InitializeComponent();
            size = App.context.Size.ToList().Find(s => s.IdSize == Size);
            Name.Text = tovar.NameModel + " (" + size.SizeTovar + ")";
            this.tovar = tovar;
            BitmapImage img = new BitmapImage();
            MemoryStream ms = new MemoryStream(tovar.Photo);
            img.BeginInit();
            img.StreamSource = ms;
            img.EndInit();
            Img.Source = img;
        }
        CatalogTovar tovar;
        Models.Size size;

        private void Back_MouseEnter(object sender, MouseEventArgs e)
        {
            Back.Background = MouseEnter.Background;
        }

        private void Back_MouseLeave(object sender, MouseEventArgs e)
        {
            Back.Background = MouseLeave.Background;
        }

        private void Back_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Classes.Basket.tovars.Remove(tovar);
            Classes.Basket.Sizes.Remove(size.IdSize);
            Classes.Navigation.cart.LoadData();
        }
    }
}
