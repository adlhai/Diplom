﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Client.UserControls
{
    /// <summary>
    /// Логика взаимодействия для Order.xaml
    /// </summary>
    public partial class Order : UserControl
    {
        Models.Orders order;
        public Order(Models.Orders order)
        {
            InitializeComponent();
            this.order = order;
            Number.Text += order.IdOrder.ToString();
            When.Text += order.DateOrder.ToString("dd.MM.yyyy");
            Status.Text = order.MetodOplata;
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Classes.Navigation.history.LoadSpecs(order);
        }
    }
}
