﻿using magazin.Classes;
using magazin.Client.Pages.Cart;
using magazin.Models;
using magazin.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace magazin.Client
{
    /// <summary>
    /// Логика взаимодействия для MainMenu.xaml
    /// </summary>
    public partial class MainMenu : Window
    {
        public MainMenu()
        {
            InitializeComponent();

            User user1 = App.context.User.ToList().Find(p => p.IdUser == Convert.ToInt32(Profile.UserId));

            Role role1 = App.context.Role.ToList().Find(p => p.IdRole == user1.IdRole);

            

            voshel.Content = "Вошли как: " + user1.Fio + " (" + role1.RoleName + ")";
            Profile.FIOUSER = user1.Fio;
            Manager.MainFrame = FMain;
        }

        private void BthTovar_Click(object sender, RoutedEventArgs e)
        {
            Models.Orders order = new Models.Orders()
            {
                DateOrder = DateTime.Now,
                MetodOplata = "Новый",
                IdUser = Profile.UserId,
            };
            FMain.Navigate(new Cart(order));
        }

        private void chekbt_Click(object sender, RoutedEventArgs e)
        {
            FMain.Navigate(new Pages.History.View());
        }

        private void razmer_Click(object sender, RoutedEventArgs e)
        {
            FMain.Navigate(new Pages.Account.View());
        }

        private void pols_Click(object sender, RoutedEventArgs e)
        {
            ConstantData.auth.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (Manager.kolvoframe >= 2)
            {
                FMain.GoBack();
            }
            else
            {
                ConstantData.auth.Show();
                this.Hide();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void ButtEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BthTov_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new tovar());
        }
    }
}
