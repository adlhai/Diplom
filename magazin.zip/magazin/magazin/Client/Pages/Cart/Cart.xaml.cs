﻿using magazin.Classes;
using magazin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Client.Pages.Cart
{
    /// <summary>
    /// Логика взаимодействия для Cart.xaml
    /// </summary>
    public partial class Cart : Page
    {
        public Cart(Orders order)
        {
            InitializeComponent();
            LoadData();
            List<CatalogTovar> tovars = App.context.CatalogTovar.ToList();
            foreach (CatalogTovar tovar in tovars)
                Products.Children.Add(new UserControls.Product(tovar));
            Classes.Navigation.cart = this;
            this.order = order;
        }
        List<Models.Basket> baskets1;
        Orders order;
        private Models.Basket basket = new Models.Basket();
        public void LoadData()
        {
            baskets1 = App.context.Basket.ToList();
            if (Search1.Text != "")
            {
                baskets1 = baskets1.Where(p => p.CatalogTovarNameModel.ToLower().Contains(Search1.Text.ToLower())).ToList();
            }
            ToBuy.Children.Clear();
            int total = 0;
            if (Classes.Basket.tovars != null)
                for (int i = 0; i < Classes.Basket.tovars.Count; i++)
                {
                    total += Classes.Basket.tovars[i].Cost;
                    ToBuy.Children.Add(new UserControls.Basket(Classes.Basket.tovars[i], Classes.Basket.Sizes[i]));
                }
            Total.Text = "Итого " + total + " р.";
        }
        private void Search1_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();
        }
        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                App.context.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            }
        }

        private void BtnCheck_Click(object sender, RoutedEventArgs e)
        {
            
            Windows.PrintCheck pc = new Windows.PrintCheck(order);
            pc.Show();
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            App.context.Orders.Add(order);
            App.context.SaveChanges();
            List<CatalogTovar> list = Classes.Basket.tovars.ToList().Distinct().ToList();
            List<int> counts = new List<int>();
            foreach (var listitem in list)
            {
                int count = 0;
                foreach (var item in Classes.Basket.tovars)
                {
                    if (listitem.ArticleTovar == item.ArticleTovar)
                        count++;
                }
                counts.Add(count);
            }
            for (int i = 0; i < list.Count; i++)
            {
                Models.Basket bask = new Models.Basket();
                bask.IdCatalog = list[i].IdCatalogTovar;
                bask.IdOrder = order.IdOrder;
                bask.QuantityTovar = counts[i];
                App.context.Basket.Add(bask);
                SizeTovarCatalog stc = App.context.SizeTovarCatalog.ToList().Find(s => s.IdSize == Classes.Basket.Sizes[i] && s.IdCatalogTovar == Classes.Basket.tovars[i].IdCatalogTovar);
                try
                {
                    stc.QuantityTovar = stc.QuantityTovar - counts[i];

                }
                catch { }

                App.context.SizeTovarCatalog.Update(stc);
            }
            App.context.SaveChanges();

            

            MessageBox.Show("Заказ успешно оформлен!");
            Classes.Basket.tovars = new List<CatalogTovar>();
            order = new Orders()
            {
                DateOrder = DateTime.Now,
                MetodOplata = "Ожидание",
                IdUser = Profile.UserId,
            };
            Manager.MainFrame.Navigate(new Cart(order));
        }
    }
}
