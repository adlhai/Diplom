﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Client.Pages.History
{
    /// <summary>
    /// Логика взаимодействия для View.xaml
    /// </summary>
    public partial class View : Page
    {
        public View()
        {
            InitializeComponent();
            Classes.Navigation.history = this;
            LoadData();
        }
        public void LoadData()
        {
            Orders.Children.Clear();
            List<Models.Orders> orders = App.context.Orders.ToList().Where(o => o.IdUser == magazin.Classes.Profile.UserId).ToList();
            foreach (var item in orders)
            {
                Orders.Children.Add(new UserControls.Order(item));
            }
        }
        public void LoadSpecs(Models.Orders order)
        {
            Spec.Children.Clear();
            List<Models.Basket> productsinorder = App.context.Basket.ToList().Where(p => p.IdOrder == order.IdOrder).ToList();
            foreach (var item in productsinorder)
            {
                Models.CatalogTovar tovar = App.context.CatalogTovar.ToList().Find(t => t.IdCatalogTovar == item.IdCatalog);
                Spec.Children.Add(new UserControls.Specs(item));
            }
        }
    }
}
