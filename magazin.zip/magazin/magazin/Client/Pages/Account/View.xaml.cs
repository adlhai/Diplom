﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Client.Pages.Account
{
    /// <summary>
    /// Логика взаимодействия для View.xaml
    /// </summary>
    public partial class View : Page
    {
        private Models.User userok = Classes.Profile.client;
        public View()
        {
            InitializeComponent();
            When.DisplayDateEnd = DateTime.Now.AddYears(-18);
            Models.User users = App.context.User.ToList().Find(u => u.IdUser == magazin.Classes.Profile.UserId);
            FIO.Text = users.Fio;
            Phone.Text = users.Telephone.ToString();
            When.Text = users.DateOfBirth.ToString("dd.MM.yyyy");
            Email.Text = users.Email;
            Login.Text = users.Log;
            Password.Text = users.Pass;
        }

        private void ChangeData_Click(object sender, RoutedEventArgs e)
        {
            if (FIO.Text != null && Phone.Text != null && When.Text != null && Email.Text != null && Login.Text != null && Password.Text != null)
            {
                try
                {
                    userok.IdUser = magazin.Classes.Profile.UserId;
                    userok.Fio = FIO.Text;
                    userok.Telephone = Convert.ToDecimal(Phone.Text);
                    userok.DateOfBirth = Convert.ToDateTime(Convert.ToDateTime(When.Text).ToString("dd-MM-yyyy"));
                    userok.Email = Email.Text;
                    userok.Log = Login.Text;
                    userok.Pass = Password.Text;

                    App.context.SaveChanges();

                    MessageBox.Show("Успешная смена данных!");

                }
                catch
                {
                    MessageBox.Show("Телефон, логин или электронная почта уже заняты!");
                }
            }
            else
                MessageBox.Show("Вы должны заполнить все поля!");
        }
    }
}
