﻿using System;
using System.Collections.Generic;
using System.Text;

namespace magazin.Client.Classes
{
    internal class Profile
    {
        public static Models.User client;
    }
}
