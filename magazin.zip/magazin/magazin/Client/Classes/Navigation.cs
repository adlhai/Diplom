﻿using System;
using System.Collections.Generic;
using System.Text;

namespace magazin.Client.Classes
{
    internal class Navigation
    {
        public static Pages.Cart.Cart cart;
        public static Pages.History.View history;
    }
}
