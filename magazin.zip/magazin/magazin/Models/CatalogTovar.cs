﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace magazin.Models
{
    public partial class CatalogTovar
    {
        public CatalogTovar()
        {
            Basket = new HashSet<Basket>();
            SizeTovarCatalog = new HashSet<SizeTovarCatalog>();
        }
        public string TypeName
        {
            get
            {
                Type role = App.context.Type.ToList().Find(u => u.IdType == IdType);
                return $"{role.TypeName}";
            }
        }
        public string SeasonName
        {
            get
            {
                Season role = App.context.Season.ToList().Find(u => u.IdSeason == IdSeason);
                return $"{role.SeasonName}";
            }
        }
        public string BrandName
        {
            get
            {
                Brand role = App.context.Brand.ToList().Find(u => u.IdBrand == IdBrand);
                return $"{role.BrandName}";
            }
        }
        public string PurposeName
        {
            get
            {
                Purpose role = App.context.Purpose.ToList().Find(u => u.IdPurpose== IdPurpose);
                return $"{role.PurposeName}";
            }
        }
        public string ArticleTovar { get; set; }
        public int Cost { get; set; }
        public string DescriptionTovar { get; set; }
        public int Discount { get; set; }
        public int IdBrand { get; set; }
        public int IdCatalogTovar { get; set; }
        public int IdPurpose { get; set; }
        public int IdSeason { get; set; }
        public int IdType { get; set; }
        public string NameModel { get; set; }
        public byte[] Photo { get; set; }

        public virtual Brand IdBrandNavigation { get; set; }
        public virtual Purpose IdPurposeNavigation { get; set; }
        public virtual Season IdSeasonNavigation { get; set; }
        public virtual Type IdTypeNavigation { get; set; }
        public virtual ICollection<Basket> Basket { get; set; }
        public virtual ICollection<SizeTovarCatalog> SizeTovarCatalog { get; set; }
    }
}
