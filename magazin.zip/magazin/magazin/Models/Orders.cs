﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace magazin.Models
{
    public partial class Orders
    {
        public Orders()
        {
            Basket = new HashSet<Basket>();
        }
        public string UserFio
        {
            get
            {
                User role = App.context.User.ToList().Find(u => u.IdUser == IdUser);
                return $"{role.Fio}";
            }
        }
        public DateTime DateOrder { get; set; }
        public int IdOrder { get; set; }
        public int IdUser { get; set; }
        public string MetodOplata { get; set; }

        public virtual User IdUserNavigation { get; set; }
        public virtual ICollection<Basket> Basket { get; set; }
    }
}
