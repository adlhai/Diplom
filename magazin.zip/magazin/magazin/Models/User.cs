﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace magazin.Models
{
    public partial class User
    {
        public User()
        {
            Orders = new HashSet<Orders>();
        }
        public string RoleName {
            get
            {
                Role role = App.context.Role.ToList().Find(u => u.IdRole == IdRole);
                return $"{role.RoleName}";
            }
        }
        public DateTime DateOfBirth { get; set; }
        public string Email { get; set; }
        public string Fio { get; set; }
        public int IdRole { get; set; }
        public int IdUser { get; set; }
        public string Log { get; set; }
        public string Pass { get; set; }
        public decimal Telephone { get; set; }

        public virtual Role IdRoleNavigation { get; set; }
        public virtual ICollection<Orders> Orders { get; set; }
    }
}
