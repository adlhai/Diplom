﻿using System;
using System.Collections.Generic;

namespace magazin.Models
{
    public partial class Brand
    {
        public Brand()
        {
            CatalogTovar = new HashSet<CatalogTovar>();
        }

        public string BrandName { get; set; }
        public int IdBrand { get; set; }

        public virtual ICollection<CatalogTovar> CatalogTovar { get; set; }
    }
}
