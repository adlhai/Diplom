﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace magazin.Models
{
    public partial class Basket
    {
        public string CatalogTovarNameModel
        {
            get
            {
                CatalogTovar role = App.context.CatalogTovar.ToList().Find(u => u.IdCatalogTovar == IdCatalog);
                return $"{role.NameModel}";
            }
        }
        public string Cost
        {
            get
            {
                CatalogTovar role = App.context.CatalogTovar.ToList().Find(u => u.IdCatalogTovar == IdCatalog);
                return $"{role.Cost}";
            }
        }
        public string Article
        {
            get
            {
                CatalogTovar role = App.context.CatalogTovar.ToList().Find(u => u.IdCatalogTovar == IdCatalog);
                return $"{role.ArticleTovar}";
            }
        }
        public DateTime When
        {
            get
            {
                Orders role = App.context.Orders.ToList().Find(u => u.IdOrder == IdOrder);
                return role.DateOrder;
            }
        }
        public int IdBasket { get; set; }
        public int IdCatalog { get; set; }
        public int? IdOrder { get; set; }
        public int QuantityTovar { get; set; }

        public virtual CatalogTovar IdCatalogNavigation { get; set; }
        public virtual Orders IdOrderNavigation { get; set; }
    }
}
