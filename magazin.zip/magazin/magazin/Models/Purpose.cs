﻿using System;
using System.Collections.Generic;

namespace magazin.Models
{
    public partial class Purpose
    {
        public Purpose()
        {
            CatalogTovar = new HashSet<CatalogTovar>();
        }

        public int IdPurpose { get; set; }
        public string PurposeName { get; set; }

        public virtual ICollection<CatalogTovar> CatalogTovar { get; set; }
    }
}
