﻿using System;
using System.Collections.Generic;

namespace magazin.Models
{
    public partial class Season
    {
        public Season()
        {
            CatalogTovar = new HashSet<CatalogTovar>();
        }

        public int IdSeason { get; set; }
        public string SeasonName { get; set; }

        public virtual ICollection<CatalogTovar> CatalogTovar { get; set; }
    }
}
