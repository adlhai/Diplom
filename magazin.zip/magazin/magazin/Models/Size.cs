﻿using System;
using System.Collections.Generic;

namespace magazin.Models
{
    public partial class Size
    {
        public Size()
        {
            SizeTovarCatalog = new HashSet<SizeTovarCatalog>();
        }

        public int IdSize { get; set; }
        public int Quantity { get; set; }
        public int SizeTovar { get; set; }

        public virtual ICollection<SizeTovarCatalog> SizeTovarCatalog { get; set; }
    }
}
