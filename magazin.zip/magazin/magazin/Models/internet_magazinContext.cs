﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace magazin.Models
{
    public partial class magazinContext : DbContext
    {
        public magazinContext()
        {
        }

        public magazinContext(DbContextOptions<magazinContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Basket> Basket { get; set; }
        public virtual DbSet<Brand> Brand { get; set; }
        public virtual DbSet<CatalogTovar> CatalogTovar { get; set; }
        public virtual DbSet<Orders> Orders { get; set; }
        public virtual DbSet<Purpose> Purpose { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<Season> Season { get; set; }
        public virtual DbSet<Size> Size { get; set; }
        public virtual DbSet<SizeTovarCatalog> SizeTovarCatalog { get; set; }
        public virtual DbSet<Type> Type { get; set; }
        public virtual DbSet<User> User { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("server=localhost;user=root;password=adelina2601;database=internet_magazin");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Basket>(entity =>
            {
                entity.HasKey(e => e.IdBasket)
                    .HasName("PRIMARY");

                entity.ToTable("basket");

                entity.HasIndex(e => e.IdCatalog)
                    .HasName("id_catalog_tovar_idx");

                entity.HasIndex(e => e.IdOrder)
                    .HasName("id_order_idx");

                entity.Property(e => e.IdBasket).HasColumnName("id_basket");

                entity.Property(e => e.IdCatalog).HasColumnName("id_catalog");

                entity.Property(e => e.IdOrder).HasColumnName("id_order");

                entity.Property(e => e.QuantityTovar).HasColumnName("quantity_tovar");

                entity.HasOne(d => d.IdCatalogNavigation)
                    .WithMany(p => p.Basket)
                    .HasForeignKey(d => d.IdCatalog)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("id_catalog");

                entity.HasOne(d => d.IdOrderNavigation)
                    .WithMany(p => p.Basket)
                    .HasForeignKey(d => d.IdOrder)
                    .HasConstraintName("id_order");
            });

            modelBuilder.Entity<Brand>(entity =>
            {
                entity.HasKey(e => e.IdBrand)
                    .HasName("PRIMARY");

                entity.ToTable("brand");

                entity.Property(e => e.IdBrand).HasColumnName("id_brand");

                entity.Property(e => e.BrandName)
                    .IsRequired()
                    .HasColumnName("brand_name")
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");
            });

            modelBuilder.Entity<CatalogTovar>(entity =>
            {
                entity.HasKey(e => e.IdCatalogTovar)
                    .HasName("PRIMARY");

                entity.ToTable("catalog_tovar");

                entity.HasIndex(e => e.IdBrand)
                    .HasName("id_brand_idx");

                entity.HasIndex(e => e.IdPurpose)
                    .HasName("id_purpose_idx");

                entity.HasIndex(e => e.IdSeason)
                    .HasName("id_season_idx");

                entity.HasIndex(e => e.IdType)
                    .HasName("id_type_idx");

                entity.Property(e => e.IdCatalogTovar).HasColumnName("id_catalog_tovar");

                entity.Property(e => e.ArticleTovar)
                    .IsRequired()
                    .HasColumnName("article_tovar")
                    .HasColumnType("varchar(50)")
                    .HasCharSet("utf8mb3")
                    .HasCollation("utf8mb3_general_ci");

                entity.Property(e => e.Cost).HasColumnName("cost");

                entity.Property(e => e.DescriptionTovar)
                    .IsRequired()
                    .HasColumnName("description_tovar")
                    .HasColumnType("varchar(1000)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");

                entity.Property(e => e.Discount).HasColumnName("discount");

                entity.Property(e => e.IdBrand).HasColumnName("id_brand");

                entity.Property(e => e.IdPurpose).HasColumnName("id_purpose");

                entity.Property(e => e.IdSeason).HasColumnName("id_season");

                entity.Property(e => e.IdType).HasColumnName("id_type");

                entity.Property(e => e.NameModel)
                    .IsRequired()
                    .HasColumnName("name_model")
                    .HasColumnType("varchar(150)")
                    .HasCharSet("utf8mb3")
                    .HasCollation("utf8mb3_general_ci");

                entity.Property(e => e.Photo)
                    .IsRequired()
                    .HasColumnName("photo");

                entity.HasOne(d => d.IdBrandNavigation)
                    .WithMany(p => p.CatalogTovar)
                    .HasForeignKey(d => d.IdBrand)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("id_brand");

                entity.HasOne(d => d.IdPurposeNavigation)
                    .WithMany(p => p.CatalogTovar)
                    .HasForeignKey(d => d.IdPurpose)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("id_purpose");

                entity.HasOne(d => d.IdSeasonNavigation)
                    .WithMany(p => p.CatalogTovar)
                    .HasForeignKey(d => d.IdSeason)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("id_season");

                entity.HasOne(d => d.IdTypeNavigation)
                    .WithMany(p => p.CatalogTovar)
                    .HasForeignKey(d => d.IdType)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("id_type");
            });

            modelBuilder.Entity<Orders>(entity =>
            {
                entity.HasKey(e => e.IdOrder)
                    .HasName("PRIMARY");

                entity.ToTable("orders");

                entity.HasIndex(e => e.IdUser)
                    .HasName("id_user_idx");

                entity.Property(e => e.IdOrder).HasColumnName("id_order");

                entity.Property(e => e.DateOrder)
                    .HasColumnName("date_order")
                    .HasColumnType("date");

                entity.Property(e => e.IdUser).HasColumnName("id_user");

                entity.Property(e => e.MetodOplata)
                    .IsRequired()
                    .HasColumnName("metod_oplata")
                    .HasColumnType("varchar(50)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");

                entity.HasOne(d => d.IdUserNavigation)
                    .WithMany(p => p.Orders)
                    .HasForeignKey(d => d.IdUser)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("id_user");
            });

            modelBuilder.Entity<Purpose>(entity =>
            {
                entity.HasKey(e => e.IdPurpose)
                    .HasName("PRIMARY");

                entity.ToTable("purpose");

                entity.Property(e => e.IdPurpose).HasColumnName("id_purpose");

                entity.Property(e => e.PurposeName)
                    .IsRequired()
                    .HasColumnName("purpose_name")
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.IdRole)
                    .HasName("PRIMARY");

                entity.ToTable("role");

                entity.Property(e => e.IdRole).HasColumnName("id_role");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasColumnName("role_name")
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");
            });

            modelBuilder.Entity<Season>(entity =>
            {
                entity.HasKey(e => e.IdSeason)
                    .HasName("PRIMARY");

                entity.ToTable("season");

                entity.Property(e => e.IdSeason).HasColumnName("id_season");

                entity.Property(e => e.SeasonName)
                    .IsRequired()
                    .HasColumnName("season_name")
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");
            });

            modelBuilder.Entity<Size>(entity =>
            {
                entity.HasKey(e => e.IdSize)
                    .HasName("PRIMARY");

                entity.ToTable("size");

                entity.Property(e => e.IdSize).HasColumnName("id_size");

                entity.Property(e => e.Quantity).HasColumnName("quantity");

                entity.Property(e => e.SizeTovar).HasColumnName("size_tovar");
            });

            modelBuilder.Entity<SizeTovarCatalog>(entity =>
            {
                entity.HasKey(e => e.IdSizeTovarCatalog)
                    .HasName("PRIMARY");

                entity.ToTable("size_tovar_catalog");

                entity.HasIndex(e => e.IdCatalogTovar)
                    .HasName("id_catalog_tovar_idx");

                entity.HasIndex(e => e.IdSize)
                    .HasName("id_size_idx");

                entity.Property(e => e.IdSizeTovarCatalog).HasColumnName("id_size_tovar_catalog");

                entity.Property(e => e.IdCatalogTovar).HasColumnName("id_catalog_tovar");

                entity.Property(e => e.IdSize).HasColumnName("id_size");

                entity.Property(e => e.QuantityTovar).HasColumnName("quantity_tovar");

                entity.HasOne(d => d.IdCatalogTovarNavigation)
                    .WithMany(p => p.SizeTovarCatalog)
                    .HasForeignKey(d => d.IdCatalogTovar)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("id_catalog_tovar");

                entity.HasOne(d => d.IdSizeNavigation)
                    .WithMany(p => p.SizeTovarCatalog)
                    .HasForeignKey(d => d.IdSize)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("id_size");
            });

            modelBuilder.Entity<Type>(entity =>
            {
                entity.HasKey(e => e.IdType)
                    .HasName("PRIMARY");

                entity.ToTable("type");

                entity.Property(e => e.IdType).HasColumnName("id_type");

                entity.Property(e => e.TypeName)
                    .IsRequired()
                    .HasColumnName("type_name")
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.IdUser)
                    .HasName("PRIMARY");

                entity.ToTable("user");

                entity.HasIndex(e => e.Email)
                    .HasName("email_UNIQUE")
                    .IsUnique();

                entity.HasIndex(e => e.IdRole)
                    .HasName("id_role_idx");

                entity.HasIndex(e => e.Log)
                    .HasName("log_UNIQUE")
                    .IsUnique();

                entity.HasIndex(e => e.Telephone)
                    .HasName("telephone_UNIQUE")
                    .IsUnique();

                entity.Property(e => e.IdUser).HasColumnName("id_user");

                entity.Property(e => e.DateOfBirth)
                    .HasColumnName("date_of_birth")
                    .HasColumnType("date");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email")
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb3")
                    .HasCollation("utf8mb3_general_ci");

                entity.Property(e => e.Fio)
                    .IsRequired()
                    .HasColumnName("fio")
                    .HasColumnType("varchar(150)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");

                entity.Property(e => e.IdRole).HasColumnName("id_role");

                entity.Property(e => e.Log)
                    .IsRequired()
                    .HasColumnName("log")
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb3")
                    .HasCollation("utf8mb3_general_ci");

                entity.Property(e => e.Pass)
                    .IsRequired()
                    .HasColumnName("pass")
                    .HasColumnType("varchar(100)")
                    .HasCharSet("utf8mb4")
                    .HasCollation("utf8mb4_0900_ai_ci");

                entity.Property(e => e.Telephone)
                    .HasColumnName("telephone")
                    .HasColumnType("decimal(11,0)");

                entity.HasOne(d => d.IdRoleNavigation)
                    .WithMany(p => p.User)
                    .HasForeignKey(d => d.IdRole)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("id_role");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
