﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace magazin.Models
{
    public partial class SizeTovarCatalog
    {
        public int IdCatalogTovar { get; set; }
        public int IdSize { get; set; }
        public int IdSizeTovarCatalog { get; set; }
        public int QuantityTovar { get; set; }

        public virtual CatalogTovar IdCatalogTovarNavigation { get; set; }
        public virtual Size IdSizeNavigation { get; set; }

        public string ModelName
        {
            get
            {
                CatalogTovar role = App.context.CatalogTovar.ToList().Find(u => u.IdCatalogTovar == IdCatalogTovar);
                if(role != null)
                {
                    return $"{role.NameModel}";
                }
                return null;
            }
        }
        public string SizeName
        {
            get
            {
                Size role = App.context.Size.ToList().Find(u => u.IdSize == IdSize);
                if (role != null)
                {
                    return $"{role.SizeTovar}";
                }
                return null;
            }
        }
       
    }
}
