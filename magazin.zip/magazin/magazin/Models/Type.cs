﻿using System;
using System.Collections.Generic;

namespace magazin.Models
{
    public partial class Type
    {
        public Type()
        {
            CatalogTovar = new HashSet<CatalogTovar>();
        }

        public int IdType { get; set; }
        public string TypeName { get; set; }

        public virtual ICollection<CatalogTovar> CatalogTovar { get; set; }
    }
}
