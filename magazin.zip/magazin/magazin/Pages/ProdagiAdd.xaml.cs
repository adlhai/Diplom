﻿using magazin.Classes;
using magazin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProdagiAdd.xaml
    /// </summary>
    public partial class ProdagiAdd : Page
    {
        private Orders orders = new Orders();
        string combovalue = "NULLABLE";
        public ProdagiAdd(Orders _prodagi)
        {
            InitializeComponent();

            if (_prodagi != null)
            {
                orders = _prodagi;
                User user = App.context.User.ToList().Find(p => p.IdUser == _prodagi.IdUser);
                //fiot.Text = user.RoleName;
                //combovalue = fiot.Text;
            }

            DataContext = orders;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            Orders ord = new Orders();
            ord.DateOrder = DateTime.Now;
            ord.IdUser = Profile.UserId;
            ord.MetodOplata = oplata.Text;
            App.context.Orders.Add(ord);
            try
            {

                App.context.SaveChanges();
                MessageBox.Show("Информация добавлена");
                Manager.MainFrame.Navigate(new Chek(ord));
                return;
            }
            catch
            {

                MessageBox.Show("Заполните все поля!");

            }
        }

        private void Date_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void oplata_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            {
                char l = e.Text[0];
                if ((l < 'A' || l < 'z') && l != '\b' && l != '.' && l != ' ')
                {
                    e.Handled = true;
                }
            }
        }
    }
}
