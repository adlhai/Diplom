﻿using magazin.Classes;
using magazin.Models;
using Microsoft.Office.Interop.Excel;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTable = System.Data.DataTable;
using Excel = Microsoft.Office.Interop.Excel;

namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для Prodagi.xaml
    /// </summary>
    public partial class Prodagi : System.Windows.Controls.Page
    {
        List<Orders> order1;
        List<Orders> order3;
        private Orders order2 = new Orders();
        List<Orders> orders4;
        string connectionString = "Server = localhost;Database = internet_magazin;UID= root;password=adelina2601";
        public Prodagi()
        {
            InitializeComponent();

            User user1 = App.context.User.ToList().Find(p => p.IdUser == Convert.ToInt32(Profile.UserId));

            Role role1 = App.context.Role.ToList().Find(p => p.IdRole == user1.IdRole);

            Classes.Basket.tovars = new List<CatalogTovar>();

            if (user1.IdRole == 1)
            {
                
                BtnAdd.Visibility = Visibility.Visible;
               
            }
            else
            {
               
                BtnAdd.Visibility = Visibility.Hidden;
                
            }

            List<User> users = App.context.User.ToList().Where(u => u.IdRole == 1).ToList();
            foreach (var item in users)
            {
                Filter.Items.Add(item.Fio);
            }
            LoadData();
        }
        public void LoadData()
        {
            order1 = App.context.Orders.ToList();
            if (Search1.Text != "")
            {
                order1 = order1.Where(p => p.UserFio.ToLower().Contains(Search1.Text.ToLower())).ToList();
            }
            if (Filter.SelectedItem != null)
                order1 = order1.Where(o => o.UserFio == Filter.Text).ToList();

            Prods.Children.Clear();
            foreach (var item in order1)
            {
                Prods.Children.Add(new UserControls.Prodagis(item));
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            User user1 = App.context.User.ToList().Find(u => u.IdUser == Profile.UserId);
            if (user1.IdRole == 2)
            {
                Manager.MainFrame.Navigate(new ProdagiAdd((sender as System.Windows.Controls.Button).DataContext as Orders));
            }
            else
            {
                MessageBox.Show("У вас нет доступа", "Ошибка");
            }
            
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new ProdagiAdd(null));
        }

       

        private void Search1_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                App.context.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            }
        }

        private void OtchetBtn_Click(object sender, RoutedEventArgs e)
        {
            Windows.PrintOtchet o = new Windows.PrintOtchet(Convert.ToDateTime(DateOt.DisplayDate), Convert.ToDateTime(DatePo.Text));
            o.Show();
        }

        private void DateOt_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            DatePo.DisplayDateStart = Convert.ToDateTime(DateOt.Text);
            DatePo.IsEnabled = true;
        }

        private void DatePo_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            OtchetBtn.IsEnabled = true;
        }

        private void Filter_DropDownClosed(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}



