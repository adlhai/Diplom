﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Linq;
using magazin.Models;
using magazin.Classes;
using MySql.Data.MySqlClient;
using System.Data;

namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для UserPage.xaml
    /// </summary>
    public partial class UserPage : Page
    {

        List<User> users;
        private User user = new User();
        public UserPage()
        {
            InitializeComponent();
            DGrid.ItemsSource = App.context.User.ToList();
            DataContext = user;
            LoadData();
            
            
        }
        public void LoadData()
        {
            users = App.context.User.ToList();
            if (Search1.Text != "")
            {
                users = users.Where(p => p.Fio.ToLower().Contains(Search1.Text.ToLower()) && p.IdRole == 1).ToList();
            }
            DGrid.ItemsSource = users;
        }




        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new PageAddUser((sender as Button).DataContext as User));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new PageAddUser(null));
        }

        private void BtnDelet_Click(object sender, RoutedEventArgs e)
        {
            var deadproject = DGrid.SelectedItems.Cast<User>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие{deadproject.Count()} элеметов", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    App.context.User.RemoveRange(deadproject);
                    App.context.SaveChanges();
                    MessageBox.Show("Информация удалена");
                    DGrid.ItemsSource = App.context.User.ToList();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                App.context.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());

                DGrid.ItemsSource = App.context.User.ToList().Where(u => u.IdRole != 2);
            }
        }

       

        private void Search1_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();

        }


    }
}
