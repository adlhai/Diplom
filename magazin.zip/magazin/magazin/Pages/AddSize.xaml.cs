﻿using magazin.Classes;
using magazin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddSize.xaml
    /// </summary>
    public partial class AddSize : Page
    {
        private Models.SizeTovarCatalog basket = new Models.SizeTovarCatalog();
        string combovalue = "NULLABLE";
        public AddSize(Models.SizeTovarCatalog _basket)
        {
            InitializeComponent();
            model.ItemsSource = App.context.CatalogTovar.ToList().Select(p => p.NameModel);
            razmer.ItemsSource = App.context.Size.ToList().Select(p => p.SizeTovar);

            if (_basket != null)
            {
                basket = _basket;
                CatalogTovar orders = App.context.CatalogTovar.ToList().Find(p => p.IdCatalogTovar == _basket.IdCatalogTovar);
                model.Text = orders.NameModel;
                combovalue = model.Text;

                Models.Size catalog = App.context.Size.ToList().Find(p => p.IdSize == _basket.IdSize);
                razmer.Text = Convert.ToString(catalog.SizeTovar);
                combovalue = razmer.Text;
                kol.Text = _basket.QuantityTovar.ToString();
            }

            DataContext = basket;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder builder = new StringBuilder();

            if (builder.Length > 0)
            {
                MessageBox.Show(builder.ToString());
            }
            CatalogTovar orders = App.context.CatalogTovar.ToList().Find(u => u.NameModel == model.Text);

            basket.IdCatalogTovar = orders.IdCatalogTovar;
            Models.Size catalog = App.context.Size.ToList().Find(u => u.SizeTovar == Convert.ToInt32(razmer.Text));

            basket.IdSize = catalog.IdSize;
            basket.QuantityTovar = Convert.ToInt32(kol.Text);
            //basket.IdSize = catalog.IdSize;
            if (combovalue == "NULLABLE")
            {

                App.context.SizeTovarCatalog.Add(basket);
            }

            try
            {

                App.context.SaveChanges();
                MessageBox.Show("Информация добавлена");
                Manager.MainFrame.GoBack();
                return;
            }
            catch (Exception ex)
            {

                MessageBox.Show("Заполните все поля!");

            }
        }
    }
}
