﻿using magazin.Classes;
using magazin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для Razmer.xaml
    /// </summary>
    public partial class Razmer : Page
    {
        List<SizeTovarCatalog> size;
        private SizeTovarCatalog siz = new SizeTovarCatalog();
        public Razmer()
        {
            InitializeComponent();

            DGrid.ItemsSource = App.context.SizeTovarCatalog.ToList();
            DataContext = siz;
            LoadData();
        }

        public void LoadData()
        {
            size = App.context.SizeTovarCatalog.ToList();
            if (Search1.Text != "")
            {
                size = size.Where(p => p.ModelName.ToLower().Contains(Search1.Text.ToLower())).ToList();
            }

            DGrid.ItemsSource = size;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Pages.AddSize((sender as Button).DataContext as Models.SizeTovarCatalog));
        }

        private void BtnDelet_Click(object sender, RoutedEventArgs e)
        {
            var deadproject = DGrid.SelectedItems.Cast<SizeTovarCatalog>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие{deadproject.Count()} элеметов", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    App.context.SizeTovarCatalog.RemoveRange(deadproject);
                    App.context.SaveChanges();
                    MessageBox.Show("Информация удалена");
                    DGrid.ItemsSource = App.context.SizeTovarCatalog.ToList();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddSize(null));
        }

        private void Search1_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                App.context.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGrid.ItemsSource = App.context.SizeTovarCatalog.ToList();
                LoadData();
            }
        }
    }
}
