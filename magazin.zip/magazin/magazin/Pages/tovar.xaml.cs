﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using magazin.Models;
using magazin.Classes;
using System.Linq;

namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для tovar.xaml
    /// </summary>
    public partial class tovar : Page
    {
        List<CatalogTovar> tovars;
        public tovar()
        {
            InitializeComponent();
            LoadData();
            User user1 = App.context.User.ToList().Find(u => u.IdUser == Profile.UserId);
            if (user1.IdRole == 2)
            {
                addbut.Visibility = Visibility.Visible;

                
            }
            else
            {
                addbut.Visibility = Visibility.Hidden;
            }


        }
        public void LoadData()
        {
            SPcatalog.Children.Clear();
            tovars = App.context.CatalogTovar.ToList();
            if (Search.Text != "")
            {
                tovars = tovars.Where(p => p.NameModel.ToLower().Contains(Search.Text.ToLower())).ToList();
            }
            switch (Filtration.SelectedIndex)
            {
                case 1:
                    tovars = tovars.OrderByDescending(p => p.Cost).ToList();
                    break;
                case 2:
                    tovars = tovars.OrderBy(p => p.Cost).ToList();
                    break;
            }
            switch (Sort.SelectedIndex)
            {

                case 1:
                    tovars = tovars.Where(p => p.BrandName == "Nike").ToList();
                    break;
                case 2:
                    tovars = tovars.Where(p => p.BrandName == "Adidas").ToList();
                    break;
                case 3:
                    tovars = tovars.Where(p => p.BrandName == "Puma").ToList();
                    break;
                case 4:
                    tovars = tovars.Where(p => p.BrandName == "New Balance").ToList();
                    break;
                case 5:
                    tovars = tovars.Where(p => p.BrandName == "Reebok").ToList();
                    break;
            }
            switch (Sort1.SelectedIndex)
            {

                case 1:
                    tovars = tovars.Where(p => p.TypeName == "Мужское").ToList();
                    break;
                case 2:
                    tovars = tovars.Where(p => p.TypeName == "Женское").ToList();
                    break;
                case 3:
                    tovars = tovars.Where(p => p.TypeName == "Детское").ToList();
                    break;
                
            }
            int filter = tovars.Count;
            foreach (var item in tovars)
            {
                SPcatalog.Children.Add(new UserControls.Catalog(item));

            }
        }

        private void addbut_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new TovarAdd(null));
        }
       
        private void Desc_Checked(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void Asc_Checked(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void Filtration_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
        }

        private void Sort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                App.context.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                LoadData();
            }
        }

    }
}
