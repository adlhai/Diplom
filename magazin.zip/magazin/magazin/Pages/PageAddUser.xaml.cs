﻿using magazin.Classes;
using magazin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddUser.xaml
    /// </summary>
    public partial class PageAddUser : Page
    {
        private User user = new User();
        
        string combovalue = "NULLABLE";

        public PageAddUser(User _user)
        {
            InitializeComponent();
            NameRole.ItemsSource = App.context.Role.ToList().Select(p => p.RoleName);

            if (_user != null)
            {
                user = _user;
                Role role = App.context.Role.ToList().Find(p => p.IdRole == _user.IdRole);
                NameRole.Text = role.RoleName;
                combovalue = NameRole.Text;
            }
            
            DataContext = user;
 
            
        }

       

        int GetDifferenceInYears(DateTime startDate, DateTime endDate)
        {
            return (endDate.Year - startDate.Year - 1) +
                (((endDate.Month > startDate.Month) ||
                ((endDate.Month == startDate.Month) && (endDate.Day >= startDate.Day))) ? 1 : 0);
        }
        private void Date_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            
            var ageInYears = GetDifferenceInYears(Date.SelectedDate.Value, DateTime.Today);
            if (ageInYears < 18)
            {
                UserEmail.IsEnabled = false;

                UserEmail.IsEnabled = false;

                BtnSave.IsEnabled = false;

                NameRole.IsEnabled = false;

                UserLogin.IsEnabled = false;

                UserPassword.IsEnabled = false;

                MessageBox.Show("Вам еще нет 18");
            }
            else if (ageInYears > 18)
            {
                UserEmail.IsEnabled = true;

                BtnSave.IsEnabled = true;

                UserEmail.IsEnabled = true;

                NameRole.IsEnabled = true;

                UserLogin.IsEnabled = true;

                UserPassword.IsEnabled = true;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            
            StringBuilder builder = new StringBuilder();

            if (string.IsNullOrEmpty(user.Fio))
            {
                builder.AppendLine("Укажите Фамилию, имя, отчество ");
            }
            if (string.IsNullOrEmpty(user.Email))
            {
                builder.AppendLine("Укажите электронную почту");
            }
            if (string.IsNullOrEmpty(user.Log))
            {
                builder.AppendLine("Укажите логин");
            }
            if (string.IsNullOrEmpty(user.Pass))
            {
                builder.AppendLine("Укажите пароль");
            }
            if (string.IsNullOrEmpty(NameRole.Text))
            {
                builder.AppendLine("Укажите роль");
                
            }


            if (builder.Length > 0)
            {
                MessageBox.Show(builder.ToString());
            }
            Role role = App.context.Role.ToList().Find(u => u.RoleName == NameRole.Text);
            user.IdRole = role.IdRole;
            if (combovalue == "NULLABLE")
            {
                App.context.User.Add(user);
            }
            
            try
            {
                
                App.context.SaveChanges();
                MessageBox.Show("Информация добавлена");
                Manager.MainFrame.GoBack();
                return;
            }
            catch (Exception ex)
            {

                MessageBox.Show("Заполните все поля!");

            }
        }

       

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
           
        }

        private void BtnSaveiz_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void Userfio_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            char l = e.Text[0];
            if ((l < 'A' || l < 'z') && l != '\b' && l != '.' && l != ' ')
            {
                e.Handled = true;
            }
        }
    }
}
