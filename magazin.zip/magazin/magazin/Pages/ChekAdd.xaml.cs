﻿using magazin.Classes;
using magazin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для ChekAdd.xaml
    /// </summary>
    public partial class ChekAdd : Page
    {
        private Models.Basket basket = new Models.Basket();
        string combovalue = "NULLABLE";
        public ChekAdd(Models.Basket _basket)
        {
            InitializeComponent();
            prod.ItemsSource = App.context.Orders.ToList().Select(p => p.IdOrder);
            name.ItemsSource = App.context.CatalogTovar.ToList().Select(p => p.NameModel);

            if (_basket != null)
            {
                basket = _basket;
                Orders orders = App.context.Orders.ToList().Find(p => p.IdOrder == _basket.IdOrder);
                
                combovalue = prod.Text;

                CatalogTovar catalog = App.context.CatalogTovar.ToList().Find(p => p.IdCatalogTovar == _basket.IdCatalog);
                name.Text = catalog.NameModel;
                combovalue = name.Text;
            }

            DataContext = basket;

            
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder builder = new StringBuilder();

            if (builder.Length > 0)
            {
                MessageBox.Show(builder.ToString());
            }
            Orders orders = App.context.Orders.ToList().Find(u => u.IdOrder == prod.SelectedIndex);
            //basket.IdOrder = orders.IdOrder;

            CatalogTovar catalog = App.context.CatalogTovar.ToList().Find(u => u.NameModel == name.Text);
            basket.IdCatalog = catalog.IdCatalogTovar;
            if (combovalue == "NULLABLE")
            {
                App.context.Basket.Add(basket);
            }

            try
            {

                App.context.SaveChanges();
                MessageBox.Show("Информация добавлена");
                Manager.MainFrame.GoBack();
                return;
            }
            catch (Exception ex)
            {

                MessageBox.Show("Заполните все поля!");

            }
        }
    }
}
