﻿using magazin.Classes;
using magazin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Excel = Microsoft.Office.Interop.Excel;
using System.Windows.Shapes;


namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для Chek.xaml
    /// </summary>
    public partial class Chek : Page
    {
        
        public Chek(Orders order)
        {
            InitializeComponent();
            LoadData();
            List<CatalogTovar> tovars = App.context.CatalogTovar.ToList();
            foreach (CatalogTovar tovar in tovars)
                Products.Children.Add(new UserControls.Product(tovar));
            Update.chek = this;
            this.order = order;
        }
        List<Models.Basket> baskets1;
        Orders order;
        private Models.Basket basket = new Models.Basket();
        public void LoadData()
        {
            baskets1 = App.context.Basket.ToList();
            if (Search1.Text != "")
            {
                baskets1 = baskets1.Where(p => p.CatalogTovarNameModel.ToLower().Contains(Search1.Text.ToLower())).ToList();
            }
            ToBuy.Children.Clear();
            int total = 0;
            if (Classes.Basket.tovars != null)
                for (int i = 0; i < Classes.Basket.tovars.Count; i++)
                {
                    total += Classes.Basket.tovars[i].Cost;
                    ToBuy.Children.Add(new UserControls.Basket(Classes.Basket.tovars[i], Classes.Basket.Sizes[i]));
                }
            Total.Text = "Итого: " + total + " р.";
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new ChekAdd(null));
        }
        private void Search1_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new ChekAdd((sender as Button).DataContext as Models.Basket));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                App.context.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            }
        }

        private void BtnCheck_Click(object sender, RoutedEventArgs e)
        {
            List<CatalogTovar> list = Classes.Basket.tovars.ToList().Distinct().ToList();
            List<int> counts = new List<int>();
            foreach (var listitem in list)
            {
                int count = 0;
                foreach (var item in Classes.Basket.tovars)
                {
                    if (listitem.ArticleTovar == item.ArticleTovar)
                        count++;
                }
                counts.Add(count);
            }
            for (int i = 0; i < list.Count; i++)
            {
                Models.Basket bask = new Models.Basket();
                bask.IdCatalog = list[i].IdCatalogTovar;
                bask.IdOrder = order.IdOrder;
                bask.QuantityTovar = counts[i];
                App.context.Basket.Add(bask);
                SizeTovarCatalog stc = App.context.SizeTovarCatalog.ToList().Find(s => s.IdSize == Classes.Basket.Sizes[i] && s.IdCatalogTovar == Classes.Basket.tovars[i].IdCatalogTovar);
                stc.QuantityTovar = stc.QuantityTovar - counts[i];

                App.context.SizeTovarCatalog.Update(stc);
            }
            App.context.SaveChanges();
            Windows.PrintCheck pc = new Windows.PrintCheck(order);
            pc.Show();
            Classes.Manager.MainFrame.Navigate(new Prodagi());
        }
    }
}

