﻿using magazin.Classes;
using magazin.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace magazin.Pages
{
    /// <summary>
    /// Логика взаимодействия для TovarAdd.xaml
    /// </summary>
    public partial class TovarAdd : Page
    {
        private CatalogTovar tovar = new CatalogTovar();
        string combovalue = "NULLABLE";
        public TovarAdd(CatalogTovar _tovar)
        {
            InitializeComponent();
            TovarBrand.ItemsSource = App.context.Brand.ToList().Select(p => p.BrandName);
            TovarPurpose.ItemsSource = App.context.Purpose.ToList().Select(p => p.PurposeName);
            TovarType.ItemsSource = App.context.Type.ToList().Select(p => p.TypeName);
            TovarSeason.ItemsSource = App.context.Season.ToList().Select(p => p.SeasonName);

            if (_tovar != null)
            {
                tovar = _tovar;
                Brand brand = App.context.Brand.ToList().Find(p => p.IdBrand == _tovar.IdBrand);
                TovarBrand.Text = brand.BrandName;
                Purpose purpose = App.context.Purpose.ToList().Find(p => p.IdPurpose == _tovar.IdPurpose);
                TovarPurpose.Text = purpose.PurposeName;
                Models.Type type = App.context.Type.ToList().Find(p => p.IdType == _tovar.IdType);
                TovarType.Text = type.TypeName;
                Season season = App.context.Season.ToList().Find(p => p.IdSeason == _tovar.IdSeason);
                TovarSeason.Text = season.SeasonName;
              
                combovalue = TovarBrand.Text;
            }

            DataContext = tovar;

        }

        string fileName = null;
        public string GetPath()
        {
            var dialog = new OpenFileDialog();
            dialog.Filter = "Image files (*.BMP, *.JPG, *.GIF, *.TIF, *.PNG, *.ICO, *.EMF, *.WMF)|*.bmp;*.jpg;*.gif; *.tif; *.png; *.ico; *.emf; *.wmf";
            if (dialog.ShowDialog() == true)
            {
                fileName = dialog.FileName.ToString();
                TovarImage.Source = new BitmapImage(new Uri(fileName));
                return dialog.FileName;
            }
            return null;

        }

        public byte[] getJPGFromImageControl(BitmapImage imageC)
        {
            MemoryStream memStream = new MemoryStream();
            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(imageC));
            encoder.Save(memStream);
            return memStream.ToArray();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder builder = new StringBuilder();

            if (string.IsNullOrEmpty(tovar.ArticleTovar))
            {
                builder.AppendLine("Укажите артикул");
            }
            if (string.IsNullOrEmpty(tovar.NameModel))
            {
                builder.AppendLine("Укажите наименование модели");
            }
            if (string.IsNullOrEmpty(tovar.BrandName))
            {
                builder.AppendLine("Укажите бренд");
            }
            if (string.IsNullOrEmpty(tovar.PurposeName))
            {
                builder.AppendLine("Укажите назначение");
            }
            if (string.IsNullOrEmpty(tovar.TypeName))
            {
                builder.AppendLine("Укажите тип");

            }
            if (string.IsNullOrEmpty(tovar.SeasonName))
            {
                builder.AppendLine("Укажите сезон");

            }
            if (string.IsNullOrEmpty(tovar.DescriptionTovar))
            {
                builder.AppendLine("Укажите описание");

            }
            


            if (builder.Length > 0)
            {
                MessageBox.Show(builder.ToString());
            }
            Models.Brand brand = App.context.Brand.ToList().Find(u => u.BrandName == TovarBrand.Text);
            tovar.IdBrand = brand.IdBrand;

            Models.Purpose purpose = App.context.Purpose.ToList().Find(u => u.PurposeName == TovarPurpose.Text);
            tovar.IdPurpose = purpose.IdPurpose;

            Models.Type type = App.context.Type.ToList().Find(u => u.TypeName == TovarType.Text);
            tovar.IdType = type.IdType;

            Season season = App.context.Season.ToList().Find(u => u.SeasonName == TovarSeason.Text);
            tovar.IdSeason = season.IdSeason;

            if (combovalue == "NULLABLE")
            {
                tovar.Photo = getJPGFromImageControl(TovarImage.Source as BitmapImage);
                App.context.CatalogTovar.Add(tovar);
            }

            try
            {

                App.context.SaveChanges();
                MessageBox.Show("Информация добавлена");
                Manager.MainFrame.GoBack();
                return;
            }
            catch (Exception ex)
            {

                MessageBox.Show("Заполните все поля!");

            }
        }

        private void AddPhotoButton_Click(object sender, RoutedEventArgs e)
        {
            GetPath();
        }

        private void TovarName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void TovarCost_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void TovarArticle_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void TovarDescription_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }
    }

}
