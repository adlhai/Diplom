﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using magazin.Models;
using System.Linq;
namespace magazin.Windows
{
    /// <summary>
    /// Логика взаимодействия для PrintCheck.xaml
    /// </summary>
    public partial class PrintCheck : Window
    {
        public PrintCheck(Orders order)
        {
            InitializeComponent();
            int totalcost = 0;
            List<Basket> baskets = App.context.Basket.ToList().Where(b => b.IdOrder == order.IdOrder).ToList();

            List<CatalogTovar> list = new List<CatalogTovar>();
            foreach (var item in baskets)
            {
                CatalogTovar tovar = App.context.CatalogTovar.ToList().Find(t => t.IdCatalogTovar == item.IdCatalog);
                list.Add(tovar);
            }
            List<int> counts = new List<int>();
                int count = 0;
            int i = 0;
            foreach (Basket basket in baskets)
            {
                Positions.Children.Add(new UserControls.Position(basket, i));
                totalcost += Convert.ToInt32(basket.Cost) * basket.QuantityTovar;
                i++;
            }
            //if (Classes.Basket.discount != 0)
            //{
            //    totalcost = totalcost - (totalcost * Classes.Basket.discount / 100);
            //    TotalText.Text = "Итого с учётом скидки в 10%(руб.):";
            //}
            Number.Text += order.IdOrder;
            Date.Text += DateTime.Now.ToString().Split(' ')[0];
            Cassier.Text += Classes.Profile.FIOUSER;
            Total.Text = totalcost.ToString();
            PrintDialog p = new PrintDialog();
            if (p.ShowDialog() == true)
            {
                p.PrintVisual(ChekGrid, "Печать");
            }
        }
    }
}
