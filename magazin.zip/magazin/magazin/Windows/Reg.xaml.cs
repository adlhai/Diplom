﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace magazin.Windows
{
    /// <summary>
    /// Логика взаимодействия для Reg.xaml
    /// </summary>
    public partial class Reg : Window
    {
        public Reg()
        {
            InitializeComponent();
        }

        private void ChangeData_Click(object sender, RoutedEventArgs e)
        {
            if (FIO.Text != null && Phone.Text != null && When.Text != null && Email.Text != null && Login.Text != null && Password.Text != null)
            {
                Models.User user = new Models.User()
                {
                    Fio = FIO.Text,
                    Telephone = Convert.ToDecimal(Phone.Text),
                    DateOfBirth = Convert.ToDateTime(Convert.ToDateTime(When.Text).ToString("dd-MM-yyyy")),
                    Email = Email.Text,
                    Log = Login.Text,
                    Pass = Password.Text,
                    IdRole = 3
                };
                App.context.User.Add(user);

                App.context.SaveChanges();

                MessageBox.Show("Успешная регистрация!");
            }
            else
                MessageBox.Show("Вы должны заполнить все поля!");
        }
    }
}
