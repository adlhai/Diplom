﻿using magazin.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace magazin.Windows
{
    /// <summary>
    /// Логика взаимодействия для MessageBoxMethod.xaml
    /// </summary>
    public partial class MessageBoxMethod : Window
    {
        Orders orders;
        public MessageBoxMethod(Orders orders)
        {
            InitializeComponent();
            this.orders = orders;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            orders.MetodOplata = oplata.Text;
            App.context.SaveChanges();
            Classes.Manager.MainFrame.Navigate(new Pages.Prodagi());
            this.Close();
        }
    }
}
