﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace magazin.Windows
{
    /// <summary>
    /// Логика взаимодействия для PrintOtchet.xaml
    /// </summary>
    public partial class PrintOtchet : Window
    {
        public PrintOtchet(DateTime begin, DateTime end)
        {
            InitializeComponent();
            Number.Text += " " + begin.ToString("dd.MM.yyyy") + " по " + end.ToString("dd.MM.yyyy");
            Date.Text = DateTime.Now.ToString("dd.MM.yyyy");
            List<Models.Basket> baskets = App.context.Basket.ToList().Where(b => b.IdOrderNavigation.DateOrder >= begin && b.IdOrderNavigation.DateOrder <= end).ToList();
            int total = 0;
            baskets = baskets.ToList().OrderBy(b => b.When).ToList();
            foreach (var item in baskets)
            {
                Positions.Children.Add(new UserControls.Otchet(item));
                if (item.QuantityTovar >= 3)
                    total += (Convert.ToInt32(item.Cost) * Convert.ToInt32(item.QuantityTovar)) - (Convert.ToInt32(item.Cost) * Convert.ToInt32(item.QuantityTovar) / 10);
                else
                    total += Convert.ToInt32(item.Cost) * Convert.ToInt32(item.QuantityTovar);
            }
            Total.Text = total.ToString();
            Manager.Text += " " + Classes.Profile.FIOUSER;
            PrintDialog p = new PrintDialog();
            p.PrintVisual(OtchetGrid, "Печать");
        }
    }
}
