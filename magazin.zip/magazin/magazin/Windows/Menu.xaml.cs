﻿using magazin.Classes;
using magazin.Pages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq;
using magazin.Models;

namespace magazin.Windows
{
    /// <summary>
    /// Логика взаимодействия для Menu.xaml
    /// </summary>
    public partial class Menu : Window
    {
        
        
        public Menu()
        {
            InitializeComponent();
            
            User user1 = App.context.User.ToList().Find(p => p.IdUser == Convert.ToInt32(Profile.UserId));
            
            Role role1 = App.context.Role.ToList().Find(p => p.IdRole == user1.IdRole);

            if (user1.IdRole == 1)
            {
                BtnUsers.IsEnabled= false; 
            }
            else
            {
                BtnUsers.IsEnabled = true;
            }

            if (user1.IdRole == 2)
            {
                chekbt.IsEnabled = false;
            }
            else
            {
                chekbt.IsEnabled = true;
            }

            voshel.Content = "Вошли как: " + user1.Fio+ " ("+ role1.RoleName + ")";
            Profile.FIOUSER = user1.Fio;
            Manager.MainFrame = FMain;
        }
       

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
           if(Manager.kolvoframe >= 2)
            {
                FMain.GoBack();
            }
           else
            {
                Authorization authorization = new Authorization();
                authorization.Show();
                this.Hide();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void BtnUsers_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new UserPage());
        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
           
        }

        private void ButtEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BthTovar_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new tovar());
        }

        private void FMain_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            Manager.kolvoframe += 1;
        }

        private void prodagiBT_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Prodagi());
        }

        private void chekbt_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Chek(App.context.Orders.ToList()[App.context.Orders.ToList().Count - 1]));
        }

        private void pols_Click(object sender, RoutedEventArgs e)
        {
            Authorization authorization = new Authorization();
            authorization.Show();
            Hide();
        }

        private void razmer_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Razmer());
        }
    }
}
