﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using magazin.Models;
using System.Linq;
using magazin.Classes;

namespace magazin.Windows
{
    
    public partial class Authorization : Window
    {
        public Authorization()
        {
            InitializeComponent();
            Classes.ConstantData.auth = this;
            Manager.kolvoframe = 0;
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                Close();
            }
        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            if (login.Text.Length != 0 && password.Password.Length != 0)
            {
                User user = App.context.User.ToList().Find
                    (u => u.Log == login.Text && u.Pass == password.Password);
                if (user != null)
                {
                    if (user.IdRole == 3)
                    {
                        Profile.UserId = user.IdUser;
                        Client.MainMenu mm = new Client.MainMenu();
                        Client.Classes.Profile.client = user;
                        mm.Show();
                        login.Text = "";
                        password.Password = "";
                    }
                    else
                    {
                        Profile.UserId = user.IdUser;
                        
                        Menu win = new Menu();
                        win.Show();
                    }
                    this.Hide();
                }
                else
                    MessageBox.Show("Вы ввели неверные данные!");
            }
            else
                MessageBox.Show("Вы должны заполнить все поля!");
        }

        private void chek_Checked(object sender, RoutedEventArgs e)
        {
            TextBoxpass.Text = password.Password;
            password.Visibility = Visibility.Hidden;
            TextBoxpass.Visibility = Visibility.Visible;
        }

        private void chek_Unchecked(object sender, RoutedEventArgs e)
        {
            password.Password = TextBoxpass.Text;
            password.Visibility = Visibility.Visible;
            TextBoxpass.Visibility = Visibility.Hidden;
        }

        private void password_PasswordChanged(object sender, RoutedEventArgs e)
        {

        }

        private void TextBoxpass_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Reg_Click(object sender, RoutedEventArgs e)
        {
            Reg reg = new Reg();
            reg.Show();
        }
    }
}
